package mirrg.mir40.glob.api;

public interface ISlot
{

	public String getName();

}
