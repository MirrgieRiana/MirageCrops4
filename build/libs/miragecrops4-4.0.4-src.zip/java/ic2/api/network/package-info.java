@API(apiVersion="1.0", owner="IC2", provides="IC2API")
package ic2.api.network;
import cpw.mods.fml.common.API;

