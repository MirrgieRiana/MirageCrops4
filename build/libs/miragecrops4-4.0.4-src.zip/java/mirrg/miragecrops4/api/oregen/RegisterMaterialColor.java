package mirrg.miragecrops4.api.oregen;

import java.util.Hashtable;

public class RegisterMaterialColor
{

	public static Hashtable<String, Integer> instance = new Hashtable<String, Integer>();

}
