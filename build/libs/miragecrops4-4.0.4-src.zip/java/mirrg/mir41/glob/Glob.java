package mirrg.mir41.glob;

import mirrg.mir41.glob.api.IGlob;

public class Glob extends Base implements IGlob
{

	public Glob()
	{

	}

	public Glob(String name)
	{
		super(name);
	}

}
