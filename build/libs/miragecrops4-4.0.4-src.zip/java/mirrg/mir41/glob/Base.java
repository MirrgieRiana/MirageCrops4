package mirrg.mir41.glob;

public class Base
{

	private String name;

	public Base()
	{

	}

	public Base(String name)
	{
		setName(name);
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name)
	{
		this.name = name;
	}

}
