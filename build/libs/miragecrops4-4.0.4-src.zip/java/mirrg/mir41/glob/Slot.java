package mirrg.mir41.glob;

import mirrg.mir41.glob.api.ISlot;

public class Slot extends Base implements ISlot
{

	public Slot()
	{

	}

	public Slot(String name)
	{
		super(name);
	}

}
