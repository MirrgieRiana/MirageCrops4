package mirrg.mir41.glob.api;

/**
 * 小文字の名前
 */
public interface IGlob
{

	public String getName();

}
