/**
 * より厳密化されたNBTアクセスなど、NBTタグに関することを行う。<br>
 */
package mirrg.mir40.data;

