package mirrg.mir34.modding;


public interface ILoaderModule
{

	public void loadModule(IMod iMod);

}
