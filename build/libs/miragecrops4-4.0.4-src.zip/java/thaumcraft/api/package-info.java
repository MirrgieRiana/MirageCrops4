@API(owner = "Thaumcraft", apiVersion = "4.2.0.0", provides = "Thaumcraft|API")
package thaumcraft.api;

import cpw.mods.fml.common.API;
