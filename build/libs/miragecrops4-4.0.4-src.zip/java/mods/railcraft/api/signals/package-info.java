/*******************************************************************************
 * Copyright 2011-2014 CovertJaguar
 * 
 * This work (the API) is licensed under the "MIT" License, see LICENSE.txt for details.
 ******************************************************************************/
@API(apiVersion="1.1", owner="RailcraftAPI|core", provides="RailcraftAPI|signals")
package mods.railcraft.api.signals;
import cpw.mods.fml.common.API;
