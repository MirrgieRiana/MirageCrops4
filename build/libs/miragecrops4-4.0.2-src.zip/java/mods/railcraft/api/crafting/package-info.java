/*******************************************************************************
 * Copyright 2011-2014 CovertJaguar
 * 
 * This work (the API) is licensed under the "MIT" License, see LICENSE.txt for details.
 ******************************************************************************/
@API(apiVersion="1.0", owner="RailcraftAPI|core", provides="RailcraftAPI|crafting")
package mods.railcraft.api.crafting;
import cpw.mods.fml.common.API;
