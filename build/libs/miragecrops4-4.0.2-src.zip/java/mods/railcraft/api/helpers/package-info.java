/*******************************************************************************
 * Copyright 2011-2014 CovertJaguar
 * 
 * This work (the API) is licensed under the "MIT" License, see LICENSE.txt for details.
 ******************************************************************************/
@API(apiVersion="1.0", owner="RailcraftAPI|core", provides="RailcraftAPI|helpers")
package mods.railcraft.api.helpers;
import cpw.mods.fml.common.API;
