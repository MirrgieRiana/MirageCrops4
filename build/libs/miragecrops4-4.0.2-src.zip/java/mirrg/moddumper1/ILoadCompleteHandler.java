package mirrg.moddumper1;

import cpw.mods.fml.common.event.FMLLoadCompleteEvent;

public interface ILoadCompleteHandler
{

	public void handle(FMLLoadCompleteEvent event);

}
