package mirrg.moddumper1.dump.helpers;

public interface ICallable1<T>
{

	public void call(T object);

}
