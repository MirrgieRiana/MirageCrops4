package mods.railcraft.api.helpers;

/**
 *
 * @author CovertJaguar <http://www.railcraft.info/>
 */
public class Helpers {

    public static StructureHelper structures;
}
