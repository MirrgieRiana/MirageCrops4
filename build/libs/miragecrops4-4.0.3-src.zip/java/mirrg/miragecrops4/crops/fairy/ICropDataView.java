package mirrg.miragecrops4.crops.fairy;

import ic2.api.crops.ICropTile;

public interface ICropDataView
{

	public int getDataView(ICropTile crop);

}
