package mirrg.mir40.crop;

import ic2.api.crops.ICropTile;

public interface IHandlerCross
{

	public boolean canCross(ICropTile crop);

}
